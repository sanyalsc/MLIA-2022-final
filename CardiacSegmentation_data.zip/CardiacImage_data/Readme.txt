{\rtf1\ansi\ansicpg1252\cocoartf1561\cocoasubrtf600
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww16200\viewh13200\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs36 \cf0 This dataset includes three folders:\
\
* \'91Training\'92 -> 112 images with ground truth segmentation provided. You can link the image and     segmentation label by looking for the same ID.\
\
* \'91Testing1-withlabel\'92 -> 10 images with ground truth segmentation are provided for testing. You are required to compare your network predictions with the provided ground truth. \
\
* \'91Testing2->withoutlabel\'92 -> No ground truth is provided. You are required to report the network prediction. \
\
\
}